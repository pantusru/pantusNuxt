export { default as VueSuggestion } from '../..\\components\\vue-suggestion.vue'
export { default as Delivery } from '../..\\components\\Footer\\Delivery.vue'
export { default as Footer } from '../..\\components\\Footer\\index.vue'
export { default as Pantus } from '../..\\components\\Footer\\Pantus.vue'
export { default as Payment } from '../..\\components\\Footer\\Payment.vue'
export { default as Social } from '../..\\components\\Footer\\Social.vue'
export { default as FilterApplicabilities } from '../..\\components\\Forms\\FilterApplicabilities.vue'
export { default as FulterProducts } from '../..\\components\\Forms\\FulterProducts.vue'
export { default as ProductBlog } from '../..\\components\\Func\\productBlog.vue'
export { default as ProductRow } from '../..\\components\\Func\\productRow.vue'
export { default as Button } from '../..\\components\\Header\\Button.vue'
export { default as Index } from '../..\\components\\Header\\Index.vue'
export { default as Advantage } from '../..\\components\\Home\\Advantage.vue'
export { default as Chosen } from '../..\\components\\Metka\\Chosen.vue'
export { default as Authorization } from '../..\\components\\Modal\\authorization.vue'
export { default as BuyProduct } from '../..\\components\\Modal\\buyProduct.vue'
export { default as ProductImg } from '../..\\components\\Modal\\ProductImg.vue'
export { default as Share } from '../..\\components\\Modal\\share.vue'
export { default as Blog } from '../..\\components\\News\\blog.vue'
export { default as News } from '../..\\components\\News\\index.vue'
export { default as Page } from '../..\\components\\News\\page.vue'
export { default as Button } from '../..\\components\\Profile\\button.vue'
export { default as Input } from '../..\\components\\Profile\\input.vue'
export { default as Register } from '../..\\components\\register\\index.vue'
export { default as RadioForm } from '../..\\components\\register\\radioForm.vue'
export { default as Select } from '../..\\components\\register\\select.vue'
export { default as Range } from '../..\\components\\Search\\range.vue'
export { default as Cart } from '../..\\components\\Table\\cart.vue'
export { default as Offset } from '../..\\components\\Table\\offset.vue'
export { default as Product } from '../..\\components\\Table\\product.vue'
export { default as Blog } from '../..\\components\\Cart\\Blog\\index.vue'
export { default as DeleteCart } from '../..\\components\\Cart\\Button\\DeleteCart.vue'
export { default as Full } from '../..\\components\\Catalog\\Applicabilities\\full.vue'
export { default as Navbottom } from '../..\\components\\Header\\Dropdown\\Navbottom.vue'
export { default as Navtop } from '../..\\components\\Header\\Dropdown\\Navtop.vue'
export { default as NavUser } from '../..\\components\\Header\\Dropdown\\NavUser.vue'
export { default as Nav } from '../..\\components\\Header\\Nav\\index.vue'
export { default as NavBottom } from '../..\\components\\Header\\Nav\\NavBottom.vue'
export { default as Filter } from '../..\\components\\Metka\\Filter\\index.vue'
export { default as Profile } from '../..\\components\\Nav\\Profile\\index.vue'
export { default as Categories } from '../..\\components\\News\\Categories\\index.vue'
export { default as Contact } from '../..\\components\\Order\\Form\\contact.vue'
export { default as Payment } from '../..\\components\\Order\\Form\\payment.vue'
export { default as Input } from '../..\\components\\Order\\Input\\Input.vue'
export { default as Town } from '../..\\components\\Order\\Input\\Town.vue'
export { default as MyOrder } from '../..\\components\\Order\\MyOrder\\index.vue'
export { default as BuyIndex } from '../..\\components\\Products\\Button\\buyIndex.vue'
export { default as Kolvo } from '../..\\components\\Products\\Input\\kolvo.vue'
export { default as Popular } from '../..\\components\\Products\\Popular\\index.vue'
export { default as BlogRow } from '../..\\components\\Products\\Product\\blog-row.vue'
export { default as Product } from '../..\\components\\Products\\Product\\index.vue'
export { default as ButtonsReset } from '../..\\components\\Search\\buttons\\buttonsReset.vue'
export { default as ButtonSubmit } from '../..\\components\\Search\\buttons\\buttonSubmit.vue'
export { default as Panel } from '../..\\components\\Search\\Panel\\index.vue'
export { default as PanelBrand } from '../..\\components\\Search\\PanelBrand\\index.vue'
export { default as ProductPanel } from '../..\\components\\Search\\ProductPanel\\index.vue'
export { default as Table } from '../..\\components\\Search\\ProductPanel\\table.vue'
export { default as TdSort } from '../..\\components\\Search\\ProductPanel\\tdSort.vue'
export { default as Img } from '../..\\components\\Products\\Product\\Element\\img.vue'
export { default as Row } from '../..\\components\\Products\\Product\\Element\\row.vue'
export { default as Getfull } from '../..\\components\\Search\\Panel\\button\\getfull.vue'
export { default as Chexbox } from '../..\\components\\Search\\Panel\\Chexbox\\chexbox.vue'
export { default as Collapse } from '../..\\components\\Search\\Panel\\Chexbox\\Collapse.vue'
export { default as Data } from '../..\\components\\Search\\Panel\\Data\\index.vue'
export { default as ButtonAdd } from '../..\\components\\Search\\PanelApplicabilities\\Button\\ButtonAdd.vue'
export { default as Reset } from '../..\\components\\Search\\PanelApplicabilities\\Button\\Reset.vue'
export { default as Children } from '../..\\components\\Search\\PanelApplicabilities\\Select\\Children.vue'
export { default as Parent } from '../..\\components\\Search\\PanelApplicabilities\\Select\\Parent.vue'
export { default as Chexbox } from '../..\\components\\Search\\PanelBrand\\Chexbox\\index.vue'

export const LazyVueSuggestion = import('../..\\components\\vue-suggestion.vue' /* webpackChunkName: "components_vue-suggestion" */).then(c => c.default || c)
export const LazyDelivery = import('../..\\components\\Footer\\Delivery.vue' /* webpackChunkName: "components_Footer/Delivery" */).then(c => c.default || c)
export const LazyFooter = import('../..\\components\\Footer\\index.vue' /* webpackChunkName: "components_Footer/index" */).then(c => c.default || c)
export const LazyPantus = import('../..\\components\\Footer\\Pantus.vue' /* webpackChunkName: "components_Footer/Pantus" */).then(c => c.default || c)
export const LazyPayment = import('../..\\components\\Footer\\Payment.vue' /* webpackChunkName: "components_Footer/Payment" */).then(c => c.default || c)
export const LazySocial = import('../..\\components\\Footer\\Social.vue' /* webpackChunkName: "components_Footer/Social" */).then(c => c.default || c)
export const LazyFilterApplicabilities = import('../..\\components\\Forms\\FilterApplicabilities.vue' /* webpackChunkName: "components_Forms/FilterApplicabilities" */).then(c => c.default || c)
export const LazyFulterProducts = import('../..\\components\\Forms\\FulterProducts.vue' /* webpackChunkName: "components_Forms/FulterProducts" */).then(c => c.default || c)
export const LazyProductBlog = import('../..\\components\\Func\\productBlog.vue' /* webpackChunkName: "components_Func/productBlog" */).then(c => c.default || c)
export const LazyProductRow = import('../..\\components\\Func\\productRow.vue' /* webpackChunkName: "components_Func/productRow" */).then(c => c.default || c)
export const LazyButton = import('../..\\components\\Header\\Button.vue' /* webpackChunkName: "components_Header/Button" */).then(c => c.default || c)
export const LazyIndex = import('../..\\components\\Header\\Index.vue' /* webpackChunkName: "components_Header/Index" */).then(c => c.default || c)
export const LazyAdvantage = import('../..\\components\\Home\\Advantage.vue' /* webpackChunkName: "components_Home/Advantage" */).then(c => c.default || c)
export const LazyChosen = import('../..\\components\\Metka\\Chosen.vue' /* webpackChunkName: "components_Metka/Chosen" */).then(c => c.default || c)
export const LazyAuthorization = import('../..\\components\\Modal\\authorization.vue' /* webpackChunkName: "components_Modal/authorization" */).then(c => c.default || c)
export const LazyBuyProduct = import('../..\\components\\Modal\\buyProduct.vue' /* webpackChunkName: "components_Modal/buyProduct" */).then(c => c.default || c)
export const LazyProductImg = import('../..\\components\\Modal\\ProductImg.vue' /* webpackChunkName: "components_Modal/ProductImg" */).then(c => c.default || c)
export const LazyShare = import('../..\\components\\Modal\\share.vue' /* webpackChunkName: "components_Modal/share" */).then(c => c.default || c)
export const LazyBlog = import('../..\\components\\News\\blog.vue' /* webpackChunkName: "components_News/blog" */).then(c => c.default || c)
export const LazyNews = import('../..\\components\\News\\index.vue' /* webpackChunkName: "components_News/index" */).then(c => c.default || c)
export const LazyPage = import('../..\\components\\News\\page.vue' /* webpackChunkName: "components_News/page" */).then(c => c.default || c)
export const LazyButton = import('../..\\components\\Profile\\button.vue' /* webpackChunkName: "components_Profile/button" */).then(c => c.default || c)
export const LazyInput = import('../..\\components\\Profile\\input.vue' /* webpackChunkName: "components_Profile/input" */).then(c => c.default || c)
export const LazyRegister = import('../..\\components\\register\\index.vue' /* webpackChunkName: "components_register/index" */).then(c => c.default || c)
export const LazyRadioForm = import('../..\\components\\register\\radioForm.vue' /* webpackChunkName: "components_register/radioForm" */).then(c => c.default || c)
export const LazySelect = import('../..\\components\\register\\select.vue' /* webpackChunkName: "components_register/select" */).then(c => c.default || c)
export const LazyRange = import('../..\\components\\Search\\range.vue' /* webpackChunkName: "components_Search/range" */).then(c => c.default || c)
export const LazyCart = import('../..\\components\\Table\\cart.vue' /* webpackChunkName: "components_Table/cart" */).then(c => c.default || c)
export const LazyOffset = import('../..\\components\\Table\\offset.vue' /* webpackChunkName: "components_Table/offset" */).then(c => c.default || c)
export const LazyProduct = import('../..\\components\\Table\\product.vue' /* webpackChunkName: "components_Table/product" */).then(c => c.default || c)
export const LazyBlog = import('../..\\components\\Cart\\Blog\\index.vue' /* webpackChunkName: "components_Cart/Blog/index" */).then(c => c.default || c)
export const LazyDeleteCart = import('../..\\components\\Cart\\Button\\DeleteCart.vue' /* webpackChunkName: "components_Cart/Button/DeleteCart" */).then(c => c.default || c)
export const LazyFull = import('../..\\components\\Catalog\\Applicabilities\\full.vue' /* webpackChunkName: "components_Catalog/Applicabilities/full" */).then(c => c.default || c)
export const LazyNavbottom = import('../..\\components\\Header\\Dropdown\\Navbottom.vue' /* webpackChunkName: "components_Header/Dropdown/Navbottom" */).then(c => c.default || c)
export const LazyNavtop = import('../..\\components\\Header\\Dropdown\\Navtop.vue' /* webpackChunkName: "components_Header/Dropdown/Navtop" */).then(c => c.default || c)
export const LazyNavUser = import('../..\\components\\Header\\Dropdown\\NavUser.vue' /* webpackChunkName: "components_Header/Dropdown/NavUser" */).then(c => c.default || c)
export const LazyNav = import('../..\\components\\Header\\Nav\\index.vue' /* webpackChunkName: "components_Header/Nav/index" */).then(c => c.default || c)
export const LazyNavBottom = import('../..\\components\\Header\\Nav\\NavBottom.vue' /* webpackChunkName: "components_Header/Nav/NavBottom" */).then(c => c.default || c)
export const LazyFilter = import('../..\\components\\Metka\\Filter\\index.vue' /* webpackChunkName: "components_Metka/Filter/index" */).then(c => c.default || c)
export const LazyProfile = import('../..\\components\\Nav\\Profile\\index.vue' /* webpackChunkName: "components_Nav/Profile/index" */).then(c => c.default || c)
export const LazyCategories = import('../..\\components\\News\\Categories\\index.vue' /* webpackChunkName: "components_News/Categories/index" */).then(c => c.default || c)
export const LazyContact = import('../..\\components\\Order\\Form\\contact.vue' /* webpackChunkName: "components_Order/Form/contact" */).then(c => c.default || c)
export const LazyPayment = import('../..\\components\\Order\\Form\\payment.vue' /* webpackChunkName: "components_Order/Form/payment" */).then(c => c.default || c)
export const LazyInput = import('../..\\components\\Order\\Input\\Input.vue' /* webpackChunkName: "components_Order/Input/Input" */).then(c => c.default || c)
export const LazyTown = import('../..\\components\\Order\\Input\\Town.vue' /* webpackChunkName: "components_Order/Input/Town" */).then(c => c.default || c)
export const LazyMyOrder = import('../..\\components\\Order\\MyOrder\\index.vue' /* webpackChunkName: "components_Order/MyOrder/index" */).then(c => c.default || c)
export const LazyBuyIndex = import('../..\\components\\Products\\Button\\buyIndex.vue' /* webpackChunkName: "components_Products/Button/buyIndex" */).then(c => c.default || c)
export const LazyKolvo = import('../..\\components\\Products\\Input\\kolvo.vue' /* webpackChunkName: "components_Products/Input/kolvo" */).then(c => c.default || c)
export const LazyPopular = import('../..\\components\\Products\\Popular\\index.vue' /* webpackChunkName: "components_Products/Popular/index" */).then(c => c.default || c)
export const LazyBlogRow = import('../..\\components\\Products\\Product\\blog-row.vue' /* webpackChunkName: "components_Products/Product/blog-row" */).then(c => c.default || c)
export const LazyProduct = import('../..\\components\\Products\\Product\\index.vue' /* webpackChunkName: "components_Products/Product/index" */).then(c => c.default || c)
export const LazyButtonsReset = import('../..\\components\\Search\\buttons\\buttonsReset.vue' /* webpackChunkName: "components_Search/buttons/buttonsReset" */).then(c => c.default || c)
export const LazyButtonSubmit = import('../..\\components\\Search\\buttons\\buttonSubmit.vue' /* webpackChunkName: "components_Search/buttons/buttonSubmit" */).then(c => c.default || c)
export const LazyPanel = import('../..\\components\\Search\\Panel\\index.vue' /* webpackChunkName: "components_Search/Panel/index" */).then(c => c.default || c)
export const LazyPanelBrand = import('../..\\components\\Search\\PanelBrand\\index.vue' /* webpackChunkName: "components_Search/PanelBrand/index" */).then(c => c.default || c)
export const LazyProductPanel = import('../..\\components\\Search\\ProductPanel\\index.vue' /* webpackChunkName: "components_Search/ProductPanel/index" */).then(c => c.default || c)
export const LazyTable = import('../..\\components\\Search\\ProductPanel\\table.vue' /* webpackChunkName: "components_Search/ProductPanel/table" */).then(c => c.default || c)
export const LazyTdSort = import('../..\\components\\Search\\ProductPanel\\tdSort.vue' /* webpackChunkName: "components_Search/ProductPanel/tdSort" */).then(c => c.default || c)
export const LazyImg = import('../..\\components\\Products\\Product\\Element\\img.vue' /* webpackChunkName: "components_Products/Product/Element/img" */).then(c => c.default || c)
export const LazyRow = import('../..\\components\\Products\\Product\\Element\\row.vue' /* webpackChunkName: "components_Products/Product/Element/row" */).then(c => c.default || c)
export const LazyGetfull = import('../..\\components\\Search\\Panel\\button\\getfull.vue' /* webpackChunkName: "components_Search/Panel/button/getfull" */).then(c => c.default || c)
export const LazyChexbox = import('../..\\components\\Search\\Panel\\Chexbox\\chexbox.vue' /* webpackChunkName: "components_Search/Panel/Chexbox/chexbox" */).then(c => c.default || c)
export const LazyCollapse = import('../..\\components\\Search\\Panel\\Chexbox\\Collapse.vue' /* webpackChunkName: "components_Search/Panel/Chexbox/Collapse" */).then(c => c.default || c)
export const LazyData = import('../..\\components\\Search\\Panel\\Data\\index.vue' /* webpackChunkName: "components_Search/Panel/Data/index" */).then(c => c.default || c)
export const LazyButtonAdd = import('../..\\components\\Search\\PanelApplicabilities\\Button\\ButtonAdd.vue' /* webpackChunkName: "components_Search/PanelApplicabilities/Button/ButtonAdd" */).then(c => c.default || c)
export const LazyReset = import('../..\\components\\Search\\PanelApplicabilities\\Button\\Reset.vue' /* webpackChunkName: "components_Search/PanelApplicabilities/Button/Reset" */).then(c => c.default || c)
export const LazyChildren = import('../..\\components\\Search\\PanelApplicabilities\\Select\\Children.vue' /* webpackChunkName: "components_Search/PanelApplicabilities/Select/Children" */).then(c => c.default || c)
export const LazyParent = import('../..\\components\\Search\\PanelApplicabilities\\Select\\Parent.vue' /* webpackChunkName: "components_Search/PanelApplicabilities/Select/Parent" */).then(c => c.default || c)
export const LazyChexbox = import('../..\\components\\Search\\PanelBrand\\Chexbox\\index.vue' /* webpackChunkName: "components_Search/PanelBrand/Chexbox/index" */).then(c => c.default || c)

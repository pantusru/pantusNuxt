const middleware = {}

middleware['CheckGuest'] = require('..\\middleware\\CheckGuest.js')
middleware['CheckGuest'] = middleware['CheckGuest'].default || middleware['CheckGuest']

middleware['CheckUser'] = require('..\\middleware\\CheckUser.js')
middleware['CheckUser'] = middleware['CheckUser'].default || middleware['CheckUser']

middleware['user'] = require('..\\middleware\\user.js')
middleware['user'] = middleware['user'].default || middleware['user']

export default middleware

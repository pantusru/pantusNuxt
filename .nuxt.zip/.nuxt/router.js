import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _01e97847 = () => interopDefault(import('..\\pages\\applicabilities\\index.vue' /* webpackChunkName: "pages/applicabilities/index" */))
const _0d29203e = () => interopDefault(import('..\\pages\\brands\\index.vue' /* webpackChunkName: "pages/brands/index" */))
const _19b2166a = () => interopDefault(import('..\\pages\\cart\\index.vue' /* webpackChunkName: "pages/cart/index" */))
const _5dd45dee = () => interopDefault(import('..\\pages\\categories\\index.vue' /* webpackChunkName: "pages/categories/index" */))
const _5b278bb3 = () => interopDefault(import('..\\pages\\forgot_password\\index.vue' /* webpackChunkName: "pages/forgot_password/index" */))
const _3ab1c71c = () => interopDefault(import('..\\pages\\my_orders\\index.vue' /* webpackChunkName: "pages/my_orders/index" */))
const _1e7448d7 = () => interopDefault(import('..\\pages\\news\\index.vue' /* webpackChunkName: "pages/news/index" */))
const _6cc9983c = () => interopDefault(import('..\\pages\\order\\index.vue' /* webpackChunkName: "pages/order/index" */))
const _786d4701 = () => interopDefault(import('..\\pages\\profile\\index.vue' /* webpackChunkName: "pages/profile/index" */))
const _00a459f2 = () => interopDefault(import('..\\pages\\register\\index.vue' /* webpackChunkName: "pages/register/index" */))
const _385a9ee2 = () => interopDefault(import('..\\pages\\search\\index.vue' /* webpackChunkName: "pages/search/index" */))
const _5e1737e2 = () => interopDefault(import('..\\pages\\selected\\index.vue' /* webpackChunkName: "pages/selected/index" */))
const _37dea8dc = () => interopDefault(import('..\\pages\\new\\_id.vue' /* webpackChunkName: "pages/new/_id" */))
const _535c94ff = () => interopDefault(import('..\\pages\\news\\_id.vue' /* webpackChunkName: "pages/news/_id" */))
const _4c842123 = () => interopDefault(import('..\\pages\\product\\_id.vue' /* webpackChunkName: "pages/product/_id" */))
const _6e054dec = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/applicabilities",
    component: _01e97847,
    name: "applicabilities"
  }, {
    path: "/brands",
    component: _0d29203e,
    name: "brands"
  }, {
    path: "/cart",
    component: _19b2166a,
    name: "cart"
  }, {
    path: "/categories",
    component: _5dd45dee,
    name: "categories"
  }, {
    path: "/forgot_password",
    component: _5b278bb3,
    name: "forgot_password"
  }, {
    path: "/my_orders",
    component: _3ab1c71c,
    name: "my_orders"
  }, {
    path: "/news",
    component: _1e7448d7,
    name: "news"
  }, {
    path: "/order",
    component: _6cc9983c,
    name: "order"
  }, {
    path: "/profile",
    component: _786d4701,
    name: "profile"
  }, {
    path: "/register",
    component: _00a459f2,
    name: "register"
  }, {
    path: "/search",
    component: _385a9ee2,
    name: "search"
  }, {
    path: "/selected",
    component: _5e1737e2,
    name: "selected"
  }, {
    path: "/new/:id?",
    component: _37dea8dc,
    name: "new-id"
  }, {
    path: "/news/:id",
    component: _535c94ff,
    name: "news-id"
  }, {
    path: "/product/:id?",
    component: _4c842123,
    name: "product-id"
  }, {
    path: "/",
    component: _6e054dec,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}

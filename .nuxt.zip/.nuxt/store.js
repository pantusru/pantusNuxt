import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const VUEX_PROPERTIES = ['state', 'getters', 'actions', 'mutations']

let store = {};

(function updateModules () {
  store = normalizeRoot(require('..\\store\\index.js'), 'store/index.js')

  // If store is an exported method = classic mode (deprecated)

  // Enforce store modules
  store.modules = store.modules || {}

  resolveStoreModules(require('..\\store\\formSearch.js'), 'formSearch.js')
  resolveStoreModules(require('..\\store\\User\\index.js'), 'User/index.js')
  resolveStoreModules(require('..\\store\\Products\\index.js'), 'Products/index.js')
  resolveStoreModules(require('..\\store\\MyOrder\\index.js'), 'MyOrder/index.js')
  resolveStoreModules(require('..\\store\\Modal\\index.js'), 'Modal/index.js')
  resolveStoreModules(require('..\\store\\API\\axios.js'), 'API/axios.js')
  resolveStoreModules(require('..\\store\\Applicabilities\\ApplicabilitiessAll.js'), 'Applicabilities/ApplicabilitiessAll.js')
  resolveStoreModules(require('..\\store\\Applicabilities\\axios.js'), 'Applicabilities/axios.js')
  resolveStoreModules(require('..\\store\\Applicabilities\\Panel.js'), 'Applicabilities/Panel.js')
  resolveStoreModules(require('..\\store\\Applicabilities\\PanelUrl.js'), 'Applicabilities/PanelUrl.js')
  resolveStoreModules(require('..\\store\\Brand\\axios.js'), 'Brand/axios.js')
  resolveStoreModules(require('..\\store\\Brand\\BrandAll.js'), 'Brand/BrandAll.js')
  resolveStoreModules(require('..\\store\\Cart\\axios.js'), 'Cart/axios.js')
  resolveStoreModules(require('..\\store\\Cart\\CartAll.js'), 'Cart/CartAll.js')
  resolveStoreModules(require('..\\store\\Catalog\\All.js'), 'Catalog/All.js')
  resolveStoreModules(require('..\\store\\Catalog\\Chexbox.js'), 'Catalog/Chexbox.js')
  resolveStoreModules(require('..\\store\\Catalog\\Metks.js'), 'Catalog/Metks.js')
  resolveStoreModules(require('..\\store\\Catalog\\Visible.js'), 'Catalog/Visible.js')
  resolveStoreModules(require('..\\store\\Categories\\axios.js'), 'Categories/axios.js')
  resolveStoreModules(require('..\\store\\Categories\\CategoriesAll.js'), 'Categories/CategoriesAll.js')
  resolveStoreModules(require('..\\store\\MyOrder\\axios.js'), 'MyOrder/axios.js')
  resolveStoreModules(require('..\\store\\News\\axios.js'), 'News/axios.js')
  resolveStoreModules(require('..\\store\\News\\CategoriesAll.js'), 'News/CategoriesAll.js')
  resolveStoreModules(require('..\\store\\News\\NewsCategoriesPage.js'), 'News/NewsCategoriesPage.js')
  resolveStoreModules(require('..\\store\\News\\NewsId.js'), 'News/NewsId.js')
  resolveStoreModules(require('..\\store\\News\\NewsIndex.js'), 'News/NewsIndex.js')
  resolveStoreModules(require('..\\store\\News\\NewsPage.js'), 'News/NewsPage.js')
  resolveStoreModules(require('..\\store\\Order\\Form.js'), 'Order/Form.js')
  resolveStoreModules(require('..\\store\\Products\\analogs.js'), 'Products/analogs.js')
  resolveStoreModules(require('..\\store\\Products\\axios.js'), 'Products/axios.js')
  resolveStoreModules(require('..\\store\\Selected\\axios.js'), 'Selected/axios.js')
  resolveStoreModules(require('..\\store\\Selected\\selected.js'), 'Selected/selected.js')
  resolveStoreModules(require('..\\store\\User\\axios.js'), 'User/axios.js')
  resolveStoreModules(require('..\\store\\Order\\Payment\\axios.js'), 'Order/Payment/axios.js')
  resolveStoreModules(require('..\\store\\Order\\Payment\\Index.js'), 'Order/Payment/Index.js')

  // If the environment supports hot reloading...
})()

// createStore
export const createStore = store instanceof Function ? store : () => {
  return new Vuex.Store(Object.assign({
    strict: (process.env.NODE_ENV !== 'production')
  }, store))
}

function normalizeRoot (moduleData, filePath) {
  moduleData = moduleData.default || moduleData

  if (moduleData.commit) {
    throw new Error(`[nuxt] ${filePath} should export a method that returns a Vuex instance.`)
  }

  if (typeof moduleData !== 'function') {
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData)
  }
  return normalizeModule(moduleData, filePath)
}

function normalizeModule (moduleData, filePath) {
  if (moduleData.state && typeof moduleData.state !== 'function') {
    console.warn(`'state' should be a method that returns an object in ${filePath}`)

    const state = Object.assign({}, moduleData.state)
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData, { state: () => state })
  }
  return moduleData
}

function resolveStoreModules (moduleData, filename) {
  moduleData = moduleData.default || moduleData
  // Remove store src + extension (./foo/index.js -> foo/index)
  const namespace = filename.replace(/\.(js|mjs)$/, '')
  const namespaces = namespace.split('/')
  let moduleName = namespaces[namespaces.length - 1]
  const filePath = `store/${filename}`

  moduleData = moduleName === 'state'
    ? normalizeState(moduleData, filePath)
    : normalizeModule(moduleData, filePath)

  // If src is a known Vuex property
  if (VUEX_PROPERTIES.includes(moduleName)) {
    const property = moduleName
    const storeModule = getStoreModule(store, namespaces, { isProperty: true })

    // Replace state since it's a function
    mergeProperty(storeModule, moduleData, property)
    return
  }

  // If file is foo/index.js, it should be saved as foo
  const isIndexModule = (moduleName === 'index')
  if (isIndexModule) {
    namespaces.pop()
    moduleName = namespaces[namespaces.length - 1]
  }

  const storeModule = getStoreModule(store, namespaces)

  for (const property of VUEX_PROPERTIES) {
    mergeProperty(storeModule, moduleData[property], property)
  }

  if (moduleData.namespaced === false) {
    delete storeModule.namespaced
  }
}

function normalizeState (moduleData, filePath) {
  if (typeof moduleData !== 'function') {
    console.warn(`${filePath} should export a method that returns an object`)
    const state = Object.assign({}, moduleData)
    return () => state
  }
  return normalizeModule(moduleData, filePath)
}

function getStoreModule (storeModule, namespaces, { isProperty = false } = {}) {
  // If ./mutations.js
  if (!namespaces.length || (isProperty && namespaces.length === 1)) {
    return storeModule
  }

  const namespace = namespaces.shift()

  storeModule.modules[namespace] = storeModule.modules[namespace] || {}
  storeModule.modules[namespace].namespaced = true
  storeModule.modules[namespace].modules = storeModule.modules[namespace].modules || {}

  return getStoreModule(storeModule.modules[namespace], namespaces, { isProperty })
}

function mergeProperty (storeModule, moduleData, property) {
  if (!moduleData) {
    return
  }

  if (property === 'state') {
    storeModule.state = moduleData || storeModule.state
  } else {
    storeModule[property] = Object.assign({}, storeModule[property], moduleData)
  }
}

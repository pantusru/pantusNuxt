export const mutations  =  {
    SetAllVisible(store, data){
        data.data.visible = data.value;
    },
}
    